// Demo: Particles, Tweens, Animations — Engine2D
// Click to spawn explosions, hover for trails, press 1-3 for effects

#include "Engine.hpp"
#include <cstdlib>
#include <ctime>
#include <sstream>

int main() {
    std::srand((unsigned)std::time(nullptr));

    EngineConfig cfg;
    cfg.title  = "Engine2D — Particles & Tweens";
    cfg.width  = 900;
    cfg.height = 600;
    cfg.vsync  = true;
    Engine engine(cfg);

    auto& sc = engine.scene();
    AudioManager audio;

    // ── Bouncing ball with tween ────────────────────────────
    auto& ball = sc.createEntity("ball");
    auto& bt = ball.addComponent<Transform>();
    bt.position = {450, 300};
    auto& bs = ball.addComponent<Sprite>();
    bs.size = {24, 24};
    bs.fillColor = {80, 200, 120, 255};
    bs.useFill = true;
    bs.layer = 1;

    // ── Particle emitter entity (trail) ────────────────────
    auto& trail = sc.createEntity("trail");
    auto& trt = trail.addComponent<Transform>();
    trt.position = {450, 300};
    auto& pe = trail.addComponent<ParticleEmitter>();
    pe.config.velMin    = {-20, -20};
    pe.config.velMax    = {20, 20};
    pe.config.lifeMin   = 0.3f;
    pe.config.lifeMax   = 0.6f;
    pe.config.sizeStart = 5.f;
    pe.config.sizeEnd   = 0.f;
    pe.config.colorStart= {100, 220, 255, 200};
    pe.config.colorEnd  = {20, 80, 200, 0};
    pe.config.gravity   = 60.f;
    pe.config.rate      = 60.f;

    // ── Tween for ball X movement ──────────────────────────
    Tween tweenX(80.f, 800.f, 2.5f, Ease::inOutQuad);
    Tween tweenY(100.f, 480.f, 1.8f, Ease::outBounce);
    Tween scaleT(1.0f, 1.4f, 0.4f, Ease::outElastic);
    bool tweenXDir = false, tweenYDir = false;

    // ── Explosion spawner ──────────────────────────────────
    struct Explosion {
        ParticleEmitter emitter;
        Vec2 pos;
        float life;
    };
    std::vector<Explosion> explosions;

    auto spawnExplosion = [&](Vec2 pos, Color c1, Color c2) {
        Explosion ex;
        ex.pos  = pos;
        ex.life = 1.5f;
        ex.emitter.config.velMin     = {-200, -250};
        ex.emitter.config.velMax     = {200, -50};
        ex.emitter.config.lifeMin    = 0.5f;
        ex.emitter.config.lifeMax    = 1.2f;
        ex.emitter.config.sizeStart  = 8.f;
        ex.emitter.config.sizeEnd    = 1.f;
        ex.emitter.config.colorStart = c1;
        ex.emitter.config.colorEnd   = c2;
        ex.emitter.config.gravity    = 300.f;
        ex.emitter.config.burstCount = 0;
        ex.emitter.config.active     = false;
        ex.emitter.burst(60);
        explosions.push_back(std::move(ex));
        audio.playBeep(300 + std::rand()%400, 60, 0.3f);
    };

    // ── Stars background ──────────────────────────────────
    struct Star { Vec2 pos; float size; float twinkle; };
    std::vector<Star> stars;
    for (int i = 0; i < 120; i++) {
        stars.push_back({
            {(float)(std::rand()%900), (float)(std::rand()%600)},
            0.5f + (float)(std::rand()%3),
            (float)(std::rand()%628)/100.f
        });
    }

    float time = 0.f;
    int   mode = 1; // 1=trail, 2=fireworks, 3=gravity rain

    // ── Rain emitter ──────────────────────────────────────
    ParticleEmitter rainEmitter;
    rainEmitter.config.velMin     = {-10, 300};
    rainEmitter.config.velMax     = {10, 500};
    rainEmitter.config.lifeMin    = 0.8f;
    rainEmitter.config.lifeMax    = 1.5f;
    rainEmitter.config.sizeStart  = 2.f;
    rainEmitter.config.sizeEnd    = 1.f;
    rainEmitter.config.colorStart = {100,180,255,220};
    rainEmitter.config.colorEnd   = {60,120,200,0};
    rainEmitter.config.gravity    = 0.f;
    rainEmitter.config.rate       = 80.f;
    rainEmitter.config.posOffset  = {};

    engine.onUpdate = [&](float dt) {
        time += dt;
        engine.renderer().clear({10, 8, 22, 255});

        // Input
        auto& inp = engine.input();
        if (inp.isKeyPressed(SDL_SCANCODE_1)) mode = 1;
        if (inp.isKeyPressed(SDL_SCANCODE_2)) mode = 2;
        if (inp.isKeyPressed(SDL_SCANCODE_3)) mode = 3;

        // Click → explosion
        if (inp.isMouseButtonPressed(1)) {
            Vec2 mp = inp.mousePosition();
            Color c1 = {(Uint8)(100+std::rand()%155), (Uint8)(std::rand()%100), (Uint8)(200+std::rand()%55), 255};
            Color c2 = {(Uint8)(200+std::rand()%55), (Uint8)(std::rand()%80), 30, 0};
            spawnExplosion(mp, c1, c2);
        }

        // ── Tween ball ─────────────────────────────────────
        tweenX.update(dt);
        tweenY.update(dt);
        scaleT.update(dt);

        if (tweenX.done()) { tweenX.reverse(); tweenXDir=!tweenXDir; }
        if (tweenY.done()) { tweenY.reverse(); tweenYDir=!tweenYDir; }
        if (scaleT.done()) scaleT.reverse();

        bt.position.x = tweenX.value();
        bt.position.y = tweenY.value();
        float sc_ = scaleT.value();
        bs.size = {24*sc_, 24*sc_};
        // Rainbow color based on time
        bs.fillColor = {
            (Uint8)(128+127*std::sin(time*1.5f)),
            (Uint8)(128+127*std::sin(time*2.1f+2)),
            (Uint8)(128+127*std::sin(time*1.8f+4)),
            255
        };

        // Trail follows ball
        trt.position = bt.position;
        pe.config.active = (mode == 1);
        pe.update(dt);

        // ── Rain mode ──────────────────────────────────────
        Vec2 rainSpawn = {(float)(std::rand()%900), -5.f};
        rainEmitter.config.posOffset = rainSpawn;
        if (mode == 3) rainEmitter.update(dt);

        // ── Fireworks auto mode ────────────────────────────
        static float fwTimer = 0;
        if (mode == 2) {
            fwTimer += dt;
            if (fwTimer > 0.5f) {
                fwTimer = 0;
                Vec2 p = {(float)(50+std::rand()%800), (float)(50+std::rand()%400)};
                Color c1 = {(Uint8)(std::rand()%256),(Uint8)(std::rand()%256),(Uint8)(std::rand()%256),255};
                Color c2 = {c1.r, c1.g, c1.b, 0};
                spawnExplosion(p, c1, c2);
            }
        }

        // Update/clean explosions
        for (auto& ex : explosions) {
            ex.emitter.update(dt);
            ex.life -= dt;
        }
        explosions.erase(std::remove_if(explosions.begin(), explosions.end(),
            [](const Explosion& e){ return e.life <= 0; }), explosions.end());
    };

    engine.onRender = [&]() {
        auto& r = engine.renderer();

        // Stars
        for (auto& s : stars) {
            float tw = 0.5f + 0.5f*std::sin(time*2+s.twinkle);
            Uint8 br = (Uint8)(150+100*tw);
            r.drawCircle(s.pos, s.size, {br,br,br,(Uint8)(180*tw)}, true);
        }

        // Rain particles
        if (mode == 3) rainEmitter.render(r, {0,0});

        // Ball trail
        if (mode == 1) pe.render(r, trt.position);

        // Explosions
        for (auto& ex : explosions)
            ex.emitter.render(r, ex.pos);

        // HUD
        std::string modeStr = (mode==1) ? "1:Trail" : (mode==2) ? "2:Fireworks" : "3:Rain";
        r.drawText("Mode: " + modeStr, {10,30}, {255,255,100,255}, 18);
        r.drawText("[1] Trail  [2] Fireworks  [3] Rain  [Click] Explosion",
                   {10,(float)(engine.windowHeight()-26)}, {160,160,160,200}, 13);
        r.drawText("Tween ball: inOutQuad X + outBounce Y + outElastic scale",
                   {10,52}, {120,180,255,180}, 12);
    };

    engine.run();
    return 0;
}
