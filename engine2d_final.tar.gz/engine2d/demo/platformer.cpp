// Demo: Mini Platformer using Engine2D
// Controls: WASD / Arrow keys to move, Space to jump, R to restart

#include "Engine.hpp"
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <iomanip>

// ─── Game constants ──────────────────────────────
static const float GRAVITY    = 900.f;
static const float JUMP_FORCE = -420.f;
static const float MOVE_SPEED = 220.f;

// ─── Utility: make a colored platform ────────────
Entity& makePlatform(Scene& sc, float x, float y, float w, float h, Color col) {
    auto& e = sc.createEntity("platform");
    auto& t = e.addComponent<Transform>();
    t.position = {x, y};
    auto& s = e.addComponent<Sprite>();
    s.size = {w, h};
    s.fillColor = col;
    s.useFill = true;
    auto& c = e.addComponent<Collider>();
    c.bounds = {0,0,w,h};
    return e;
}

// ─── Player logic ────────────────────────────────
struct PlayerData : Component {
    bool onGround   = false;
    int  jumpsLeft  = 2;   // double jump
    int  score      = 0;
    float coyoteTime = 0;  // coyote jump timer
};

// ─── Coin ────────────────────────────────────────
struct CoinData : Component {
    float bobPhase = 0;
    float baseY    = 0;
};

// ─── Main ────────────────────────────────────────
int main() {
    std::srand((unsigned)std::time(nullptr));

    EngineConfig cfg;
    cfg.title  = "Engine2D — Mini Platformer";
    cfg.width  = 900;
    cfg.height = 550;
    cfg.vsync  = true;
    Engine engine(cfg);

    // ── Build level ─────────────────────────────
    auto& sc = engine.scene();

    // Floor
    makePlatform(sc,   0, 500, 900, 50, {80, 60, 40, 255});
    // Platforms
    makePlatform(sc, 100, 400, 160, 20, {100,140,80,255});
    makePlatform(sc, 350, 330, 130, 20, {100,140,80,255});
    makePlatform(sc, 580, 260, 160, 20, {100,140,80,255});
    makePlatform(sc, 720, 380, 100, 20, {100,140,80,255});
    makePlatform(sc, 200, 220, 120, 20, {130,100,60,255});
    makePlatform(sc, 450, 160, 180, 20, {130,100,60,255});
    // Walls / sides
    makePlatform(sc, -20,   0,  20, 600, {60,50,40,255});
    makePlatform(sc, 900,   0,  20, 600, {60,50,40,255});

    // ── Coins ────────────────────────────────────
    auto spawnCoin = [&](float x, float y) {
        auto& e = sc.createEntity("coin");
        auto& t = e.addComponent<Transform>();
        t.position = {x, y};
        auto& s = e.addComponent<Sprite>();
        s.size     = {20,20};
        s.fillColor= {255,215,0,255};
        s.useFill  = true;
        s.layer    = 1;
        auto& c = e.addComponent<Collider>();
        c.bounds   = {0,0,20,20};
        c.isTrigger= true;
        auto& cd = e.addComponent<CoinData>();
        cd.baseY   = y;
        cd.bobPhase= (float)(std::rand() % 628) / 100.f;
    };
    spawnCoin(140, 360); spawnCoin(300, 380); spawnCoin(370, 285);
    spawnCoin(610, 215); spawnCoin(740, 335); spawnCoin(220, 175);
    spawnCoin(480, 110); spawnCoin(550, 110); spawnCoin(660, 240);

    // ── Player ───────────────────────────────────
    auto& player = sc.createEntity("player");
    auto& pt = player.addComponent<Transform>();
    pt.position = {60, 420};
    auto& psp = player.addComponent<Sprite>();
    psp.size     = {30, 40};
    psp.fillColor= {70, 130, 220, 255};
    psp.useFill  = true;
    psp.layer    = 2;
    player.addComponent<Velocity>();
    auto& pc = player.addComponent<Collider>();
    pc.bounds = {0, 0, 30, 40};
    player.addComponent<PlayerData>();

    // ── Player Script ────────────────────────────
    auto& ps = player.addComponent<Script>();
    ps.onUpdate = [&](Entity& self, float dt) {
        auto& tr = *self.getComponent<Transform>();
        auto& vel= *self.getComponent<Velocity>();
        auto& dat= *self.getComponent<PlayerData>();
        auto& inp= engine.input();

        // Horizontal movement
        float mx = 0;
        if (inp.isKeyDown(SDL_SCANCODE_LEFT)  || inp.isKeyDown(SDL_SCANCODE_A)) mx -= 1;
        if (inp.isKeyDown(SDL_SCANCODE_RIGHT) || inp.isKeyDown(SDL_SCANCODE_D)) mx += 1;
        vel.linear.x = mx * MOVE_SPEED;

        // Gravity
        vel.linear.y += GRAVITY * dt;

        // Coyote time
        if (dat.onGround) dat.coyoteTime = 0.12f;
        else              dat.coyoteTime -= dt;

        // Jump
        bool canJump = dat.coyoteTime > 0 || dat.jumpsLeft > 1;
        if ((inp.isKeyPressed(SDL_SCANCODE_SPACE) ||
             inp.isKeyPressed(SDL_SCANCODE_UP) ||
             inp.isKeyPressed(SDL_SCANCODE_W)) && canJump) {
            vel.linear.y = JUMP_FORCE;
            dat.jumpsLeft = (dat.coyoteTime > 0) ? 1 : dat.jumpsLeft - 1;
            dat.coyoteTime = 0;
        }

        // Collision resolution with platforms
        dat.onGround = false;
        Rect playerRect{tr.position.x, tr.position.y, 30, 40};

        for (auto* e : sc.findAllByTag("platform")) {
            auto* et = e->getComponent<Transform>();
            auto* ec = e->getComponent<Collider>();
            if (!et || !ec) continue;
            Rect platRect{et->position.x+ec->bounds.x,
                          et->position.y+ec->bounds.y,
                          ec->bounds.w, ec->bounds.h};
            if (!playerRect.overlaps(platRect)) continue;

            // Overlap resolution
            float overlapLeft  = (playerRect.x+playerRect.w) - platRect.x;
            float overlapRight = (platRect.x+platRect.w) - playerRect.x;
            float overlapTop   = (playerRect.y+playerRect.h) - platRect.y;
            float overlapBot   = (platRect.y+platRect.h) - playerRect.y;

            float minH = std::min(overlapLeft, overlapRight);
            float minV = std::min(overlapTop,  overlapBot);

            if (minV < minH) {
                if (overlapTop < overlapBot) {
                    tr.position.y -= overlapTop;
                    vel.linear.y   = 0;
                    dat.onGround   = true;
                    dat.jumpsLeft  = 2;
                } else {
                    tr.position.y += overlapBot;
                    if (vel.linear.y < 0) vel.linear.y = 0;
                }
            } else {
                if (overlapLeft < overlapRight)
                    tr.position.x -= overlapLeft;
                else
                    tr.position.x += overlapRight;
                vel.linear.x = 0;
            }
            playerRect.x = tr.position.x;
            playerRect.y = tr.position.y;
        }

        // Collect coins
        for (auto* coin : sc.findAllByTag("coin")) {
            auto* ct = coin->getComponent<Transform>();
            if (!ct) continue;
            Rect coinRect{ct->position.x, ct->position.y, 20, 20};
            if (playerRect.overlaps(coinRect)) {
                dat.score++;
                sc.destroyEntity(coin->id);
            }
        }

        // Death / restart
        if (tr.position.y > 600 || inp.isKeyPressed(SDL_SCANCODE_R)) {
            tr.position = {60, 420};
            vel.linear  = {};
            dat.score   = 0;
        }

        // Clamp to world
        tr.position.x = std::max(0.f, std::min(tr.position.x, (float)engine.windowWidth()-30));

        // Tint player when jumping vs grounded
        auto* spr = self.getComponent<Sprite>();
        if (spr) spr->fillColor = dat.onGround
            ? Color{70,130,220,255}
            : Color{120,180,255,255};
    };

    // ── Coin bob script ─────────────────────────
    for (auto* coin : sc.findAllByTag("coin")) {
        auto& cs = coin->addComponent<Script>();
        cs.onUpdate = [](Entity& self, float dt) {
            auto* cd = self.getComponent<CoinData>();
            auto* ct = self.getComponent<Transform>();
            auto* sp = self.getComponent<Sprite>();
            if (!cd || !ct || !sp) return;
            cd->bobPhase += dt * 3.0f;
            ct->position.y = cd->baseY + std::sin(cd->bobPhase) * 6.f;
            // Pulsate color
            Uint8 b = (Uint8)(200 + 55 * std::abs(std::sin(cd->bobPhase)));
            sp->fillColor = {255, b, 0, 255};
        };
    }

    // ── Custom render: HUD + background ─────────
    engine.onRender = [&]() {
        auto& r = engine.renderer();
        // HUD
        auto* ppd = player.getComponent<PlayerData>();
        if (ppd) {
            std::ostringstream oss;
            oss << "Score: " << ppd->score;
            r.drawText(oss.str(), {10, 30}, {255,255,255,255}, 20);
            r.drawText("Arrows/WASD: Move   Space: Jump   R: Reset",
                       {10, (float)engine.windowHeight()-28},
                       {180,180,180,180}, 13);
        }
        // Title
        r.drawText("Engine2D — Demo Platformer",
                   {(float)engine.windowWidth()/2 - 160, 8},
                   {200,230,255,200}, 16);
    };

    // ── Background gradient (drawn first via onStart trick) ─
    engine.onStart = [&]() {
        // nothing to init beyond scene setup
    };

    // ── Custom bg color ─────────────────────────
    // We override the clear each frame
    engine.onUpdate = [&](float) {
        engine.renderer().clear({30, 35, 55, 255});
    };

    engine.run();
    return 0;
}
